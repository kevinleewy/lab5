/*****************************************************************************
* Filename:          /home/cc/cs150/fa013/class/cs150-ax/Desktop/labs/lab5B/drivers/gcd_coprocessor_v1_00_a/src/gcd_coprocessor.c
* Version:           1.00.a
* Description:       gcd_coprocessor (new FSL core) Driver Source File
* Date:              Wed Oct  9 18:54:53 2013 (by Create and Import Peripheral Wizard)
*****************************************************************************/

#include "gcd_coprocessor.h"
/*
* Write your driver implementation in this file.
*/

