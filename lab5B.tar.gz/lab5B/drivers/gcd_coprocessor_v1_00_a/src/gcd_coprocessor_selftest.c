/*****************************************************************************
* Filename:          /home/cc/cs150/fa013/class/cs150-ax/Desktop/labs/lab5B/drivers/gcd_coprocessor_v1_00_a/src/gcd_coprocessor_selftest.c
* Version:           1.00.a
* Description:       
* Date:              Wed Oct  9 18:54:53 2013 (by Create and Import Peripheral Wizard)
*****************************************************************************/

#include "xparameters.h"
#include "gcd_coprocessor.h"

/* IMPORTANT:
*  In order to run this self test, you need to modify the value of following
*  micros according to the slot ID defined in xparameters.h file. 
*/
#define input_slot_id   XPAR_FSL_GCD_COPROCESSOR_0_INPUT_SLOT_ID
#define output_slot_id  XPAR_FSL_GCD_COPROCESSOR_0_OUTPUT_SLOT_ID

XStatus GCD_COPROCESSOR_SelfTest()
{
	 unsigned int input_0[2];     
	 unsigned int output_0[1];     

	 //Initialize your input data over here: 
	 input_0[0] = 12345;     
	 input_0[1] = 24690;     

	 //Call the macro with instance specific slot IDs
	 gcd_coprocessor(
		 input_slot_id,
		 output_slot_id,
		 input_0,      
		 output_0       
		 );

	 if (output_0[0] != 37035)
		 return XST_FAILURE;
	 if (output_0[0] != 37035)
		 return XST_FAILURE;

	 return XST_SUCCESS;
}
